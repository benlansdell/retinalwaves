The following AUTO code was used to generate homoclinic continuations of our reaction-diffusion retinal waves model in order to find heteroclinic orbits (wave-fronts), as a function of different parameters. The code comes as is, without guarantees. Please direct questions to lansdell@uw.edu

BL 10/10/2014 
