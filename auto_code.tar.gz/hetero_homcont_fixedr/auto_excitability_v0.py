from pylab import plot as pyplot
from pylab import clf, shape, matrix, xlabel, ylabel, savefig, xlim, ylim, ones, array, show, legend, savetxt
import scipy.io
import matplotlib

#Here we make some plots which find excitability thresholds for ml_sahp model...finally!
a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
r1 = run(a)
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1, NPR=100)

#Try continuing in gach until c=-0.005 and go from there
L240_gach1 = run(r2, NPR=10,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca1_fw = run(L240_gach1, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca1_bw = run(L240_gach1, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca1 = merge(gach_gca1_fw + gach_gca1_bw)

#homotopy to v0=-0.6
L240_V02 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.6, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V02, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca2 = merge(gach_gca2_fw + gach_gca2_bw)

#v0=-0.5
L240_V02a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.5, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V02a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca2a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=-0.4
L240_V03 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.4, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca3_c = run(L240_V03, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3_fw = run(gach_gca3_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3_bw = run(gach_gca3_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca3 = merge(gach_gca3_fw + gach_gca3_bw)

#v0=-0.3
L240_V03a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.3, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V03a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca3a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=-0.2
L240_V04 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.2, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca4_c = run(L240_V04, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4_fw = run(gach_gca4_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4_bw = run(gach_gca4_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca4 = merge(gach_gca4_fw + gach_gca4_bw)

#v0=-0.1
L240_V04a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.1, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V04a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca4a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=0
L240_V05 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':0, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca5_c = run(L240_V05, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5_fw = run(gach_gca5_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5_bw = run(gach_gca5_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca5 = merge(gach_gca5_fw + gach_gca5_bw)

#save data to plot
e1 = matrix(gach_gca1.toArray())
e2 = matrix(gach_gca2.toArray())
e2a = matrix(gach_gca2a.toArray())
e3 = matrix(gach_gca3.toArray())
e3a = matrix(gach_gca3a.toArray())
e4 = matrix(gach_gca4.toArray())
e4a = matrix(gach_gca4a.toArray())
e5 = matrix(gach_gca5.toArray())

#Save matrices to file to read in with MATLAB and plot
scipy.io.savemat('./excitability_v0_gca_gach.mat', mdict={'v0_0_8_gach':e1[:,0], 'v0_0_6_gach':e2[:,0], 'v0_0_5_gach':e2a[:,0], 'v0_0_4_gach':e3[:,0], 'v0_0_3_gach':e3a[:,0], 'v0_0_2_gach':e4[:,0], 'v0_0_1_gach':e4a[:,0],
'v0_0_gach':e5[:,0], 'v0_0_8_gca':e1[:,6], 'v0_0_6_gca':e2[:,6], 'v0_0_5_gca':e2a[:,6], 'v0_0_4_gca':e3[:,6], 'v0_0_3_gca':e3a[:,6], 'v0_0_2_gca':e4[:,6],'v0_0_1_gca':e4a[:,6],
'v0_0_gca':e5[:,6]})
