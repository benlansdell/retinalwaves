from pylab import plot as pyplot
from pylab import clf, shape, matrix, xlabel, ylabel, savefig, xlim, ylim, ones, array, show, legend, savetxt
import scipy.io
from pyplot import *
import matplotlib

#Here we make some plots which find excitability thresholds for ml_sahp model...finally!
a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
r1 = run(a)
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1, NPR=100)

#Try continuing in gach until c=-0.005 and go from there
L240_gach1 = run(r2, NPR=10,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca1_fw = run(L240_gach1, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca1_bw = run(L240_gach1, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca1 = merge(gach_gca1_fw + gach_gca1_bw)

#homotopy to v0=-0.6
L240_V02 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.6, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V02, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca2 = merge(gach_gca2_fw + gach_gca2_bw)

#v0=-0.5
L240_V02a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.5, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V02a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca2a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=-0.4
L240_V03 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.4, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca3_c = run(L240_V03, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3_fw = run(gach_gca3_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3_bw = run(gach_gca3_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca3 = merge(gach_gca3_fw + gach_gca3_bw)

#v0=-0.3
L240_V03a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.3, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V03a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca3a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=-0.2
L240_V04 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.2, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca4_c = run(L240_V04, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4_fw = run(gach_gca4_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4_bw = run(gach_gca4_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca4 = merge(gach_gca4_fw + gach_gca4_bw)

#v0=-0.1
L240_V04a = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.1, 'C':-0.0005}, ITNW=4000, NWTN=2000)
#then homotopy to somewhere where c is near zero
gach_gca2_c = run(L240_V04a, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_fw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(gach_gca2_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca4a = merge(gach_gca2_fw + gach_gca2_bw)

#homotopy to v0=0
L240_V05 = run(r2, NPR=10,ICP=['V0','C', 'VREST'],UZSTOP={'V0':0, 'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca5_c = run(L240_V05, NPR=10, ICP=['GACH', 'C'], UZSTOP={'GACH':0, 'C':-0.005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5_fw = run(gach_gca5_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5_bw = run(gach_gca5_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca5 = merge(gach_gca5_fw + gach_gca5_bw)

#save data to plot
e1 = matrix(gach_gca1.toArray())
e2 = matrix(gach_gca2.toArray())
e2a = matrix(gach_gca2a.toArray())
e3 = matrix(gach_gca3.toArray())
e3a = matrix(gach_gca3a.toArray())
e4 = matrix(gach_gca4.toArray())
e4a = matrix(gach_gca4a.toArray())
e5 = matrix(gach_gca5.toArray())
pyplot(e3[:,0], e3[:,6], e4[:,0], e4[:,6], e5[:,0], e5[:,6], linewidth=2.0)
center_spines()
xlabel('G_ACh')
ylabel('G_Ca')
legend(('V0 = -0.4', 'V0 = -0.2', 'V0 = 0.0'))
#show()
savefig('./auto_excitability_v0_gca_gach.eps')

#Save matrices to file to read in with MATLAB and plot
scipy.io.savemat('./excitability_v0_gca_gach.mat', mdict={'v0_0_8_gach':e1[:,0], 'v0_0_6_gach':e2[:,0], 'v0_0_5_gach':e2a[:,0], 'v0_04_gach':e3[:,0], 'v0_0_3_gach':e3a[:,0], 'v0_0_2_gach':e4[:,0], 'v0_0_1_gach':e4a[:,0],
'v0_0_gach':e5[:,0], 'v0_0_8_gca':e1[:,6], 'v0_0_6_gca':e2[:,6], 'v0_0_5_gach':e2a[:,6], 'v0_04_gca':e3[:,6], 'v0_0_3_gach':e3a[:,6], 'v0_0_2_gca':e4[:,6],'v0_0_1_gach':e4a[:,6],
'v0_0_gca':e5[:,6]})

#Homotopy to tau_ach = 30
L240_tauach1 = run(L240_V03, NPR=10,ICP=['TAUACH','C', 'VREST'],UZSTOP={'TAUACH':30,'C':-0.0005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca6_c = run(L240_tauach1, NPR=10,ICP=['GACH', 'C', 'TAUACH'], UZSTOP={'GACH':0,'C':-0.005}, ITNW=4000, NWTN=2000)
gach_gca6_fw = run(gach_gca6_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca6_bw = run(gach_gca6_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca6 = merge(gach_gca6_fw + gach_gca6_bw)
#Homotopy to tau_ach = 20
L240_tauach2 = run(L240_V03, NPR=10,ICP=['TAUACH','C', 'VREST'],UZSTOP={'TAUACH':20,'C':-0.0005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca7_c = run(L240_tauach2, NPR=10,ICP=['GACH', 'C', 'TAUACH'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca7_fw = run(gach_gca7_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca7_bw = run(gach_gca7_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca7 = merge(gach_gca7_fw + gach_gca7_bw)
#Homotopy to tau_ach = 10
L240_tauach3 = run(L240_V03, NPR=10,ICP=['TAUACH','C', 'VREST'],UZSTOP={'TAUACH':10,'C':-0.0005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca8_c = run(L240_tauach3, NPR=10,ICP=['GACH', 'C', 'TAUACH'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca8_fw = run(gach_gca8_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca8_bw = run(gach_gca8_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca8 = merge(gach_gca8_fw + gach_gca8_bw)
#Homotopy to tau_ach = 50
L240_tauach4 = run(L240_V03, NPR=10,ICP=['TAUACH','C', 'VREST'],UZSTOP={'TAUACH':50,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca9_c = run(L240_tauach4, NPR=10,ICP=['GACH', 'C', 'TAUACH'], UZSTOP={'GACH':0,'C':-0.00499}, DS='-', ITNW=4000, NWTN=2000)
gach_gca9_fw = run(gach_gca9_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca9_bw = run(gach_gca9_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca9 = merge(gach_gca9_fw + gach_gca9_bw)
#Homotopy to tau_ach = 5
L240_tauach5 = run(L240_V03, NPR=10,ICP=['TAUACH','C', 'VREST'],UZSTOP={'TAUACH':5,'C':-0.0005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca10_c = run(L240_tauach5, NPR=10,ICP=['GACH', 'C', 'TAUACH'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca10_fw = run(gach_gca10_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca10_bw = run(gach_gca10_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca10 = merge(gach_gca10_fw + gach_gca10_bw)
#save data to plot
e6 = matrix(gach_gca6.toArray())
e7 = matrix(gach_gca7.toArray())
e8 = matrix(gach_gca8.toArray())
e9 = matrix(gach_gca9.toArray())
e10 = matrix(gach_gca10.toArray())
pyplot(e6[:,0], e6[:,6], e7[:,0], e7[:,6], e8[:,0], e8[:,6], e9[:,0], e9[:,6], e10[:,0], e10[:,6], linewidth=2.0)
center_spines()
xlabel('G_ACh')
ylabel('G_Ca')
legend(('tau_ACh = 40', 'tau_ACh = 20', 'tau_ACh = 10', 'tau_ACh = 50', 'tau_ACh = 5'))
show()
#savefig('./auto_excitability_tauach_gca_gach.eps')

#Homotopy to delta = 700
L240_delta1 = run(L240_V03, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':700,'C':-0.0005}, DS='-', ITNW=4000, NWTN=2000)
gach_gca11_c = run(L240_delta1, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.005}, ITNW=4000, NWTN=2000)
gach_gca11_fw = run(gach_gca11_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca11_bw = run(gach_gca11_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca11 = merge(gach_gca11_fw + gach_gca11_bw)
#Homotopy to delta = 600
L240_delta2 = run(L240_delta1, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':600,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca12_c = run(L240_delta2, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca12_fw = run(gach_gca12_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca12_bw = run(gach_gca12_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca12 = merge(gach_gca12_fw + gach_gca12_bw)
#Homotopy to delta = 500
L240_delta3 = run(L240_delta2, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':500,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca13_c = run(L240_delta3, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca13_fw = run(gach_gca13_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca13_bw = run(gach_gca13_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca13 = merge(gach_gca13_fw + gach_gca13_bw)
#Homotopy to delta = 400
L240_delta4 = run(L240_delta3, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':400,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca14_c = run(L240_delta4, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca14_fw = run(gach_gca14_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca14_bw = run(gach_gca14_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca14 = merge(gach_gca14_fw + gach_gca14_bw)
#Homotopy to delta = 300
L240_delta5 = run(L240_delta4, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':300,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca15_c = run(L240_delta5, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca15_fw = run(gach_gca15_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca15_bw = run(gach_gca15_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca15 = merge(gach_gca15_fw + gach_gca15_bw)
#Homotopy to delta = 200
L240_delta6 = run(L240_delta5, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':200,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca16_c = run(L240_delta6, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca16_fw = run(gach_gca16_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca16_bw = run(gach_gca16_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca16 = merge(gach_gca16_fw + gach_gca16_bw)
#Homotopy to delta = 100
L240_delta7 = run(L240_delta6, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':100,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca17_c = run(L240_delta7, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca17_fw = run(gach_gca17_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca17_bw = run(gach_gca17_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca17 = merge(gach_gca17_fw + gach_gca17_bw)
#Homotopy to delta = 50
L240_delta8 = run(L240_delta7, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':50,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca18_c = run(L240_delta8, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca18_fw = run(gach_gca18_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca18_bw = run(gach_gca18_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca18 = merge(gach_gca18_fw + gach_gca18_bw)
#Homotopy to delta = 25
L240_delta9 = run(L240_delta8, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':25,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca19_c = run(L240_delta9, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca19_fw = run(gach_gca19_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca19_bw = run(gach_gca19_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca19 = merge(gach_gca19_fw + gach_gca19_bw)
#Homotopy to delta = 15
L240_delta10 = run(L240_delta9, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':15,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca20_c = run(L240_delta10, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca20_fw = run(gach_gca20_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca20_bw = run(gach_gca20_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca20 = merge(gach_gca20_fw + gach_gca20_bw)
#Homotopy to delta = 10
L240_delta11 = run(L240_delta10, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':10,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca21_c = run(L240_delta11, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca21_fw = run(gach_gca21_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca21_bw = run(gach_gca21_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca21 = merge(gach_gca21_fw + gach_gca21_bw)
#Homotopy to delta = 5
L240_delta12 = run(L240_delta11, NPR=10,ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':5,'C':-0.0005}, ITNW=4000, NWTN=2000)
gach_gca22_c = run(L240_delta12, NPR=10,ICP=['GACH', 'C', 'DELTA'], UZSTOP={'GACH':0,'C':-0.00499}, ITNW=4000, NWTN=2000)
gach_gca22_fw = run(gach_gca22_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0.004, 'GCA':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca22_bw = run(gach_gca22_c, NPR=10,ICP=['GACH','GCA', 'VREST'],UZSTOP={'GACH':0, 'GCA':0}, ITNW=4000, NWTN=2000)
gach_gca22 = merge(gach_gca22_fw + gach_gca22_bw)
#save data to plot
e11 = matrix(gach_gca11.toArray())
e12 = matrix(gach_gca12.toArray())
e13 = matrix(gach_gca13.toArray())
e14 = matrix(gach_gca14.toArray())
e15 = matrix(gach_gca15.toArray())
e16 = matrix(gach_gca16.toArray())
e17 = matrix(gach_gca17.toArray())
e18 = matrix(gach_gca18.toArray())
e19 = matrix(gach_gca19.toArray())
e20 = matrix(gach_gca20.toArray())
e21 = matrix(gach_gca21.toArray())
e22 = matrix(gach_gca22.toArray())
pyplot(e18[:,0], e18[:,6], e19[:,0], e19[:,6], e20[:,0], e20[:,6], e21[:,0], e21[:,6], e22[:,0], e22[:,6], linewidth=2.0)

scipy.io.savemat('./excitability_delta_gca_gach.mat', mdict={'delta_700_gach':e11[:,0], 'delta_600_gach':e12[:,0], 'delta_500_gach':e13[:,0], 'delta_400_gach':e14[:,0],
'delta_300_gach':e15[:,0], 'delta_200_gach':e16[:,0], 'delta_100_gach':e17[:,0], 'delta_50_gach':e18[:,0],
'delta_25_gach':e19[:,0], 'delta_15_gach':e20[:,0], 'delta_10_gach':e21[:,0], 'delta_5_gach':e22[:,0],
'delta_700_gca':e11[:,6], 'delta_600_gca':e12[:,6], 'delta_500_gca':e13[:,6], 'delta_400_gca':e14[:,6],
'delta_300_gca':e15[:,6], 'delta_200_gca':e16[:,6], 'delta_100_gca':e17[:,6], 'delta_50_gca':e18[:,6],
'delta_25_gca':e19[:,6], 'delta_15_gca':e20[:,6], 'delta_10_gca':e21[:,6], 'delta_5_gca':e22[:,6]})


center_spines()
xlabel('G_ACh')
ylabel('G_Ca')
legend(('delta = 50', 'delta = 25', 'delta = 15', 'delta = 10', 'delta = 5'))
show()
#savefig('./auto_excitability_tauach_gca_gach.eps')

scipy.io.savemat('./excitability_v0_gca_gach', mdict={'e1_gach':e1[:,0], 'e2_gach':e2[:,0], 'e3_gach':e3[:,0], 'e4_gach':e4[:,0],
'e5_gach':e5[:,0], 'e1_gca':e1[:,6], 'e2_gca':e2[:,6], 'e3_gca':e3[:,6], 'e4_gca':e4[:,6], 'e5_gca':e5[:,6]})

