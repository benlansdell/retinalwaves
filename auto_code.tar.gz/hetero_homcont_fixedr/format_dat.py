#!/usr/bin/env python
"""format_dat.py <dat file in> <dat file out>
asdfasdfasdf
<<<<<<< HEAD
asdfasdfasdf
=======
asdfasdf
asdfasdf
>>>>>>> 92158136f80a431b2c48a139e3cb8ffe586650ac
Script to translate the 'time' of integration to be all positive and between 0 and 1"""

import sys

if len(sys.argv) != 3:
        print 'Invalid arguments'
        print __doc__
        sys.exit(0)

trange = (0,1)
#Append a certain percentage of data points to start of solution -- adding more time between start of data and the front
p = 0.5 #50%

inlines = len([1 for a in open(sys.argv[1], 'r')])
fin = open(sys.argv[1], 'r')
fout = open(sys.argv[2], 'w')
tmin = -123456
ncount = 0
treps = int(inlines*p)+1
totalcount = treps + inlines*(trange[1]-trange[0])

for line in fin:
	nreps = 1
	numbers = [float(a) for a in line.split()]
	time = numbers[0]
	if tmin == -123456:
		tmin = time
		tmax = -time
		nreps = treps
		print 'original tspan:', (tmax-tmin)
		print 'new tspan:', (tmax-tmin+(tmax-tmin)*p)
		
	tscaled = (time-tmin)/(tmax-tmin)
	for i in range(nreps):
		if tscaled >= trange[0] and tscaled <= trange[1]:
			fout.write('%E\t%E\t%E\t%E\t%E\n' % ((float(ncount)/totalcount), numbers[1], numbers[2], numbers[3], numbers[4]))	
			ncount += 1
			print ncount
fin.close()
fout.close()
