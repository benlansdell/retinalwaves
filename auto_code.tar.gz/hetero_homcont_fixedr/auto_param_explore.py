a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
r1 = run(a)
#Homotopy to L=240
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1, NPR=100)
#Homotopy to gach=-0.6
L240_V0_0_6 = run(r2, NPR=1,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.6}, ITNW=4000, NWTN=2000)
L240_gach = run(L240_V0_0_6, NPR=10, ICP=['GACH','C', 'VREST'], IPSI=[], UZSTOP={'GACH':0}, DS='-', ITNW=4000, NWTN=2000)
L240_V0_0 = run(r2, NPR=1,ICP=['V0','C', 'VREST'],UZSTOP={'V0':1}, ITNW=4000, NWTN=2000)
L240_tauach = run(L240_V0_0_6, NPR=400, ICP=['TAUACH','C', 'VREST'], IPSI=[], UZSTOP={'TAUACH':2000}, NMX=150000, ITNW=4000, NWTN=2000)
L240_v1 = run(L240_V0_0_6, NPR=40, ICP=['V1','C', 'VREST'], IPSI=[], UZSTOP={'V1':0, 'C':0}, NMX=150000, ITNW=4000, NWTN=2000)
L240_v0 = run(L240_V0_0_6, NPR=20, ICP=['V0','C', 'VREST'], IPSI=[], UZSTOP={'V0':3}, NMX=150000, ITNW=4000, NWTN=2000)
L240_kappa = run(L240_V0_0_6, NPR=20, ICP=['KAPPA','C', 'VREST'], IPSI=[], UZSTOP={'KAPPA':1, 'C':0}, DS='-', NMX=150000, ITNW=4000, NWTN=2000)
L240_gca = run(L240_V0_0_6, NPR=20, ICP=['GCA','C', 'VREST'], IPSI=[], UZSTOP={'GCA':0, 'C':0}, DS='-', NMX=150000, ITNW=4000, NWTN=2000)

