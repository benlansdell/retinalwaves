from pylab import plot as pyplot
from pylab import clf, shape, matrix, xlabel, ylabel, savefig, xlim, ylim, ones, array, legend, sqrt
import matplotlib

a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
#Use dummy variable to ensure really starting at a fixed point
r1 = run(a)
plot(r1)
raw_input('press enter to continue')
#Homotopy to L=240
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1)
#Homotopy to a different value of g_ach, and again to a larger value of R
gach1 = run(r2, NPR=100,ICP=['GACH','C'],UZSTOP={'GACH':0}, DS='-', ITNW=4000,NWTN=2000)
gach2 = run(r2, NPR=100,ICP=['GACH','C'],UZSTOP={'GACH':2}, ITNW=4000,NWTN=2000)
gach = merge(gach1+gach2)

#Do the same for tau_ach
tauach1 = run(r2, NPR=100,ICP=['TAUACH','C'],UZSTOP={'TAUACH':0.01}, DS='-', ITNW=4000,NWTN=2000)
tauach2 = run(r2, NPR=100,ICP=['TAUACH','C'],UZSTOP={'TAUACH':80}, ITNW=4000,NWTN=2000)
tauach = merge(tauach1 + tauach2)

gachm = matrix(gach.toArray())
tauachm = matrix(tauach.toArray())

#Redimensionalize...
scalec = sqrt(0.01*30/0.16)
scalegach = 30;
scaletauach = 0.16/30;
scaletaus = 0.16/30;
clf
pyplot(scalegach*gachm[:,0], -scalec*gachm[:,6], linewidth=2.0)
center_spines()
xlabel('G_{ACh}')
ylabel('C')
xlim([0,5])
ylim([0,0.8])
#show()
fig = matplotlib.pyplot.gcf()
fig.set_size_inches(2,2)
savefig('./pharma_gach_fixed_r.eps')

clf
pyplot(scaletauach*tauachm[:,0], -scalec*tauachm[:,6], linewidth=2.0)
xlim([0,0.45])
ylim([0,0.6])
xlabel('tau_{ACh}')
ylabel('C')
#show()
fig = matplotlib.pyplot.gcf()
fig.set_size_inches(2,2)
savefig('./pharma_tau_ach_fixed_r.eps')
