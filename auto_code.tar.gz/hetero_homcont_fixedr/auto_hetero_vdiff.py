a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
#Use dummy variable to ensure really starting at a fixed point
r1 = run(a)
#plot(r1)
#raw_input('press enter to continue')
#Homotopy to L=240
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1, NPR=100)
#Check solution
#plot(r2)
#raw_input('press enter')
#homotopy to V0 = -0.6
L240_V0_0_6 = run(r2, NPR=1,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.6}, ITNW=4000, NWTN=2000)
L240_V0_0_4 = run(r2, NPR=1,ICP=['V0','C', 'VREST'],UZSTOP={'V0':-0.4}, ITNW=4000, NWTN=2000)
L240_V0_1 = run(r2, NPR=1,ICP=['V0','C', 'VREST'],UZSTOP={'V0':1}, DS='-', ITNW=4000, NWTN=2000)
#plot(L240_dummy)
#raw_input('press enter')
#try to homotopy to gach = 0
#find a bifurcation...
#turn on ITWIST
L240_gach = run(L240_V0_0_6, NPR=10, ICP=['GACH','C', 'VREST'], IPSI=[], UZSTOP={'GACH':0}, DS='-', ITNW=4000, NWTN=2000)
plot(L240_gach)
raw_input('press enter')
