from pylab import plot as pyplot
from pylab import clf, shape, matrix, xlabel, ylabel, savefig, xlim, ylim, ones, array, show, legend
from pyplot import *
import matplotlib

#Here we make some plots which to find wave front speed as a function of gca and gach
a = load(e='hetero_vdiff_scaled_std', c='hetero.vdiff.scaled.1')
r1 = run(a)
l1 = load(r1, c='hetero.vdiff.scaled.2')
r2 = run(l1, NPR=100)
r3 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.4, 'C':0}, ITNW=4000, NWTN=2000)
r4 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.45, 'C':0}, ITNW=4000, NWTN=2000)
r5 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.50, 'C':0}, ITNW=4000, NWTN=2000)
r6 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.55, 'C':0}, ITNW=4000, NWTN=2000)
r7 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.60, 'C':0}, ITNW=4000, NWTN=2000)
r8 = run(r2, NPR=50, ICP=['GCA','C', 'VREST'],UZSTOP={'GCA':0.65, 'C':0}, ITNW=4000, NWTN=2000)

#Try continuing in gach until and go from there
#Continue in gca from 0 to something high
gach_gca1_fw = run(r2, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca1_bw = run(r2, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':10, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca1 = merge(gach_gca1_fw + gach_gca1_bw)

#homotopy to gca = something else, then repeat
gach_gca2_fw = run(r3, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2_bw = run(r3, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':9, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca2 = merge(gach_gca2_fw + gach_gca2_bw)

gach_gca3_fw = run(r4, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3_bw = run(r4, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca3 = merge(gach_gca3_fw + gach_gca3_bw)

gach_gca4_fw = run(r5, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4_bw = run(r5, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca4 = merge(gach_gca4_fw + gach_gca4_bw)

gach_gca5_fw = run(r6, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5_bw = run(r6, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca5 = merge(gach_gca5_fw + gach_gca5_bw)

gach_gca6_fw = run(r7, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca6_bw = run(r7, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca6 = merge(gach_gca6_fw + gach_gca6_bw)

gach_gca7_fw = run(r8, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca7_bw = run(r8, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca7 = merge(gach_gca7_fw + gach_gca7_bw)

#save data to plot
e1 = matrix(gach_gca1.toArray())
e2 = matrix(gach_gca2.toArray())
e3 = matrix(gach_gca3.toArray())
e4 = matrix(gach_gca4.toArray())
e5 = matrix(gach_gca5.toArray())
e6 = matrix(gach_gca6.toArray())
e7 = matrix(gach_gca7.toArray())
pyplot(e3[:,0], e3[:,6], e4[:,0], e4[:,6], e5[:,0], e5[:,6], e6[:,0], e6[:,6], e7[:,0], e7[:,6], linewidth=2.0)
center_spines()
xlabel('G_ACh')
ylabel('C')
legend(('G_Ca = 0.45', 'G_Ca = 0.5', 'G_Ca = 0.55', 'G_Ca = 0.6', 'G_Ca = 0.65'))
#show()
savefig('./auto_wavefrontspeed_c_gca_gach.eps')

#Homotopy to delta = something else and repeat
d3 = run(r2, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':700, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
d4 = run(d3, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':400, 'C':0}, ITNW=4000, NWTN=2000)
d5 = run(d4, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':200, 'C':0}, ITNW=4000, NWTN=2000)
d6 = run(d5, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':100, 'C':0}, ITNW=4000, NWTN=2000)
d7 = run(d6, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':50, 'C':0}, ITNW=4000, NWTN=2000)
d8 = run(d7, NPR=50, ICP=['DELTA','C', 'VREST'],UZSTOP={'DELTA':25, 'C':0}, ITNW=4000, NWTN=2000)

#Try continuing in gach until and go from there
#Continue in gca from 0 to something high
gach_gca2_fw = run(d3, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca2_bw = run(d3, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':9, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca2 = merge(gach_gca2_fw + gach_gca2_bw)

gach_gca3_fw = run(d4, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca3_bw = run(d4, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca3 = merge(gach_gca3_fw + gach_gca3_bw)

gach_gca4_fw = run(d5, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca4_bw = run(d5, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca4 = merge(gach_gca4_fw + gach_gca4_bw)

gach_gca5_fw = run(d6, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca5_bw = run(d6, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca5 = merge(gach_gca5_fw + gach_gca5_bw)

gach_gca6_fw = run(d7, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca6_bw = run(d7, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca6 = merge(gach_gca6_fw + gach_gca6_bw)

gach_gca7_fw = run(d8, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':0, 'C':0}, ITNW=4000, NWTN=2000)
gach_gca7_bw = run(d8, NPR=50,ICP=['GACH','C', 'VREST'],UZSTOP={'GACH':8, 'C':0}, DS='-', ITNW=4000, NWTN=2000)
gach_gca7 = merge(gach_gca7_fw + gach_gca7_bw)

#save data to plot
e2 = matrix(gach_gca2.toArray())
e3 = matrix(gach_gca3.toArray())
e4 = matrix(gach_gca4.toArray())
e5 = matrix(gach_gca5.toArray())
e6 = matrix(gach_gca6.toArray())
e7 = matrix(gach_gca7.toArray())
pyplot(e2[:,0], e2[:,6], e3[:,0], e3[:,6], e4[:,0], e4[:,6], e5[:,0], e5[:,6], e6[:,0], e6[:,6], e7[:,0], e7[:,6], linewidth=2.0)
center_spines()
xlabel('G_ACh')
ylabel('C')
legend(('Delta = 700', 'Delta = 400', 'Delta = 200', 'Delta = 100', 'Delta = 50', 'Delta = 25'))
savefig('./auto_wavefrontspeed_c_delta_gach.eps')

#save data to output to plot
scipy.io.savemat('./wavespeeds_delta_gach.mat', mdict={'delta_700_gach':e2[:,0], 'delta_700_c':e2[:,6], 'delta_400_gach':e3[:,0], 'delta_400_c':e3[:,6], 'delta_200_gach':e4[:,0], 'delta_200_c':e4[:,6], 'delta_100_gach':e5[:,0], 'delta_100_c':e5[:,6], 'delta_50_gach':e6[:,0], 'delta_50_c':e6[:,6], 'delta_25_gach':e7[:,0], 'delta_25_c':e7[:,6]});
